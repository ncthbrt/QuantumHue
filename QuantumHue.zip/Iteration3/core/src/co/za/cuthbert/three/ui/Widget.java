package co.za.cuthbert.three.ui;

/**
 * Copyright Nick Cuthbert, 2014
 */
public interface Widget {

    public boolean inWidget(float worldX, float worldY, float objX, float objY);
}
