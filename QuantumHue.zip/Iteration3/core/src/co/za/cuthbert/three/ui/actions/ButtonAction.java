package co.za.cuthbert.three.ui.actions;

/**
 * Copyright Nick Cuthbert, 2014
 */
public abstract class ButtonAction {
    public abstract void actionPerformed(String command);

}
