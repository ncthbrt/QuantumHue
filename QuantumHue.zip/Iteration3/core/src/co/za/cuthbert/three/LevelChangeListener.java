package co.za.cuthbert.three;

/**
 * Copyright Nick Cuthbert, 2014
 */
public interface LevelChangeListener {
    public void level(Level level);
}
