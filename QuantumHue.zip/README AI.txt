This game is very much a work in progress.

It was designed from the start to be a touch first game, and hence the UI elements
on the pc may appear slightly larger than necessary. 

Only the level-editor ("create") is currently working and is missing a number of elements which 
will allow puzzle design. 

The AStar implementation is used to control entity movement in the system. 
To play with this feature, select the agent tool -> The tool with the small circles inside,
and place agents on the map, then switch to the move tool, and tap on any location with a wire.
The agents will attempt to navigate there.

I would recommend installing this on an android device, preferably a tablet.

The project will not run correctly until you have created the assets folder in the android project 
and run the pipeline project, which packs the textures in the root assets folder into an atlas.

Please contact me if you have any problems.

Regards,
Nick Cuthbert
(cthnic001, nick@cuthbert.co.za)
