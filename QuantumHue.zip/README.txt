This game is very much a work in progress.

It was designed from the start to be a touch first game, and hence the UI elements
on the pc may appear slightly larger than necessary. 

Only the level-editor ("create") is currently working and is missing a number of elements which 
will allow puzzle design. Most notable is the lack of agents. 

A* pathfinding for agents has already been coded, but the agent systems and renderers need to be created.

I would recommend installing this on an android device, preferably a tablet.

The project will not run correctly until you have created the assets folder in the android project 
and run the pipeline project, which packs the textures in the root assets folder into an atlas.

Please contact me if you have any problems.

Regards,
Nick Cuthbert
(cthnic001, nick@cuthbert.co.za)
